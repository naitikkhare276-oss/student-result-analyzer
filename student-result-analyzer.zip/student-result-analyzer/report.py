"""
report.py
Custom module for printing formatted reports.
Demonstrates: string formatting, string methods (center, ljust, rjust),
docstrings, and iteration over strings/lists.
"""

from student_utils import SUBJECTS


def print_header(title):
    """Prints a centered header, using the string center() method."""
    print("\n" + title.center(50, "="))


def print_report_card(student):
    """
    Prints a single student's report card in a neatly formatted layout
    using the string formatting operator and ljust/rjust for alignment.
    """
    print_header("REPORT CARD")
    print("Roll No : %s" % student["roll"])
    print("Name    : %s" % student["name"])
    print("-" * 40)
    for subject, mark in zip(SUBJECTS, student["marks"]):
        print(subject.ljust(15), "-", str(mark).rjust(5))
    print("-" * 40)
    print("Total".ljust(15), "-", str(student["total"]).rjust(5))
    print("Percentage".ljust(15), "-", f"{student['percentage']:.2f}%".rjust(5))
    print("Grade".ljust(15), "-", student["grade"].rjust(5))
    print("=" * 40)


def print_all_students(students):
    """Prints a summary table of all students using a for loop."""
    if not students:
        print("\nNo student records found.")
        return

    print_header("ALL STUDENT RECORDS")
    print(f"{'Roll No':<12}{'Name':<20}{'%':<8}{'Grade':<6}")
    print("-" * 46)
    for s in students:
        print(f"{s['roll']:<12}{s['name']:<20}{s['percentage']:<8.2f}{s['grade']:<6}")


def print_analytics(students, topper, pass_count, fail_count, avg):
    """Prints class-level analytics."""
    print_header("CLASS ANALYTICS")
    print(f"Total Students   : {len(students)}")
    print(f"Class Average %  : {avg:.2f}")
    print(f"Pass Count       : {pass_count}")
    print(f"Fail Count       : {fail_count}")
    if topper:
        print(f"Class Topper     : {topper['name']} ({topper['percentage']:.2f}%)")
